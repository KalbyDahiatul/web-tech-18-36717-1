<html>

<body>
<h6 style="font-weight: normal;"><spann style ="color: Red;">*</spann>- Denotes Required Information
</h6>

<h5>
>1 Donation <span style="font-weight: normal;" >>2 Confirmation >Thank you</span>
</h5>


<form>
<h4 style="color: red;">
Donor Information
</h4>
<div style="text-align: center;">
<label><b>First Name</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>Last Name</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>Company &nbsp; &nbsp;</b> </label><input type:"text"><br>
<label><b>Address 1</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>Address 2</b> </label><input type:"text"><br>
<label><b>City</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>State</b> <span style="color: red;">* </span></label>

<select >
<option value="none">Select a state</option>
<option value="Florida">Florida</option>
<option value="Texas">Texas</option>
</select><br>
<label><b>Zip Code</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>Country</b> <span style="color: red;">* </span></label>
<select >
<option value="none">Select a country</option>
<option value=:"USA">USA</option>
<option value="Canada">Canada</option>
</select><br>
<label><b>Phone</b> </label><input type:"text"><br>
<label><b>Fax</b> </label><input type:"text"><br>
<label><b>Email</b> <span style="color: red;">* </span></label><input type:"text"><br>
<label><b>Donation Amount</b> <span style="color: red;">* </span></label>
<input type="radio" id="none" value="none">
<label for="none">None</label>
<input type="radio" id="$50" value="50">
<label for="$50">$50</label>
<input type="radio" id="$75" value="75">
<label for="$75">$75</label>
<input type="radio" id="$100" value="100">
<label for="$100">$100</label>
<input type="radio" id="$250" value="250">
<label for="$250">$250</label>
<input type="radio" id="other" value="other">
<label for="none">Other</label><br>
<label><b>Other Amount $ </b> </label><input type:"text"><br>
<label><b>Recurring Donation </b> </label><input type="checkbox" id="yes" value="yes">
<label for="yes"> I am intertested in giving on a regular basis.</label><br>
<label>Monthly Credit card $ </label><input type:"text" size="4"><label>For</label><input type:"text"size="4"><label>Months</label>
</div>
<h4 style="color: red;" style="text-align:;">
Honorarium and Memorial Donation>
</h4>
<div style="text-align: center;">
<label><b>I would like to make this<br> donation</b></label>
<input type="radio" id="none" value="none">
<label for="none">To Honor</label><br>
<input type="radio" id="$50" value="50">
<label for="$50">In memory of</label><br>
<label><b>Name</b> </label><input type:"text"><br>
<label><b>Acknowledge Donation to</b> </label><input type:"text"><br>
<label><b>Address</b> </label><input type:"text"><br>
<label><b>City</b> </label><input type:"text"><br>
<label><b>State</b> </label>

<select >
<option value="none">Select a state</option>
<option value="Florida">Florida</option>
<option value="Texas">Texas</option>
</select><br>
<label><b>Zip</b> </label><input type:"text"><br>
</div>
<h4 style="color: red;" style="text-align:;">
Additional Information
</h4>
<p>
Please enter your name, company or organization as you would like to appear in our publications:
</p>
<div style="text-align: center;">
<label><b>Name</b> </label><input type:"text"><br>
</div>
<input type="checkbox" id="o1" value="yes">
<label for="o1"> I would like my gift to remain anonymous.</label><br>
<input type="checkbox" id="o2" value="yes">
<label for="o2">My employer offers a matching gift program. I will mail the matching gift form.</label><br>
<input type="checkbox" id="o3" value="yes">
<label for="o3"> Please save cost of the the acknowledgement this gift by not mailing a thank you letter.</label><br>
<div style="text-align: center;">
<label><b>Comments</b> </label><textarea name="Text1" cols="40" rows="5"></textarea><br>

<label><b>How may we contact You</b> <br>
</label>
<input type="checkbox" id="1" >
<label for="1"> Email</label><br>
<input type="checkbox" id="2">
<label for="2"> Postal Mail</label><br>
<input type="checkbox" id="3">
<label for="3"> Telephone</label><br>
<input type="checkbox" id="4">
<label for="3"> Fax</label>
</div>
<p>
I Would like to receive newsletters and information about special events by:
</p>
<div style="text-align: center;">
<input type="checkbox" id="1" >
<label for="1"> Email</label><br>
<input type="checkbox" id="2">
<label for="2"> Postal Mail</label><br>
</div>
<input type="checkbox" id="last" >
<label for="last">I would like information about voluntering with the</label><br>

<div style="text-align: center;">
<input type="reset" value="Reset">
<input type="submit" value="Continue">
</div>
</form>

<p>
Donate online with confidence. You are on a secure server.<br>
If you have any problem or questions, please contact <a href="#">Support.</a>
</p>

</body>


</html>