<!DOCTYPE html>
<html>
<head>

<title>Registration Form </title>

</head>
<body>
<table>
<h1>Registration Form</h1>
<form>
<tr>
<td> <label for="Full_Name ">Full Name : </label> </td>
<td><input type="text" id="Full_Name"></td>
</tr>


<tr>
<td> <label for="Email ">Email : </label> </td>
<td><input type="text" id="Email"></td>
</tr>


<tr>
<td> <label for="Password ">Password : </label> </td>
<td><input type="password" id="Password"></td>
</tr>

<td> Date of Birth:
            <input type="date"   value="yyyy-mm-dd" class="input-medium search-query" onkeypress="return false"size="6">


<tr>
<td> <label for="Gender ">Gender : </label> </td>
<td>
<input type="radio" id="male" name="gender" value="male">
<label for="male">Male</label>
  <input type="radio" id="female" name="gender" value="female">
  <label for="female">Female</label>
  <input type="radio" id="other" name="gender" value="other">
  <label for="other">Other</label>
</td>
</tr>
<tr>
<td> <label for="Checkbox ">Degree : </label> </td>
<td>
<input type="checkbox"  name="value1" value="SSC">
<label for="value1">SSC</label>
<input type="checkbox" name="value2" value="HSC">
<label for="value2">HSC</label>
<input type="checkbox"  name="value3" value="BSc">
<label for="value3"> BSc</label>
<input type="checkbox"  name="value3" value="MSc">
<label for="value3"> Sc</label>
</td>
</tr>
</td>
 <tr> Blood Group:
              <select name="b_group">
                <option value="A+">A+</option>
                <option value="AB+">AB+</option>
                <option value="B+">B+</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                  </select> 
</tr>
<tr>
<td> <input type="submit" name="Submit"> 

</td>
</tr>
</form>
</table>
</body>
</html>