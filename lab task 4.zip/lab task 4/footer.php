<!doctype html>
<html>
<body>
<center>hi hlw @ <?php echo date("Y");?></center></body></html>