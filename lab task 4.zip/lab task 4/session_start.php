<?php
session_start();
$_SESSION['uname'] = "";
$_SESSION['flag'] = 0;
?>