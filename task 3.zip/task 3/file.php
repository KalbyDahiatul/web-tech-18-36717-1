<?php   include "Controller\Form.php" ; ?>

<!DOCTYPE html>
<html>
<head>

<title>Profile Picture </title>

<tr>
<td> <label for="file ">Please Choose a File : </label> </td>
<td><input type="file" name="fileupload"><?php  echo  $validFile;    ?></td>
</tr>

  <input type="submit" name="submit" value="Submit" class="btn btn-info" /><br />                      
                     <?php  
                     if(isset($message))  
                     {  
                          echo $message;  
                     }  
                     ?>  
                </form>  
           </div>  
           <br />  
      </body>  
 </html>  