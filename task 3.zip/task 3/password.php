
<!DOCTYPE html>
<html>
    <head>
        <script>
          
            
            function checkPassword(form) {
                password1 = form.password1.value;
                password2 = form.password2.value;
  
                
                if (password1 == '')
                    alert ("Please enter Password");
                      
               
                else if (password2 == '')
                    alert ("Please enter confirm password");
                      
                    
                else if (password1 != password2) {
                    alert ("\nPassword did not match: Please try again...")
                    return false;
                }
  
                
                else{
                    alert("Password Match")
                    return true;
                }
            }
        </script>
        <style>
            
        </style>
    </head>
    <body>
        
        <form onSubmit = "return checkPassword(this)">
        
            <tr>
                <!-- Enter Username -->
                <td>Username:</td>
                <td><input type = text name = name size = 25</td>
            </tr>
            <tr>
                <!-- Enter Password. -->
                <td>Password:</td>
                <td><input type = password name = password1 size = 25</td>
            </tr>
            <tr>
                <!-- To Retyped Password Password. -->
                <td>Retyped Password Password:</td>
                <td><input type = password name = password2 size = 25></td>
            </tr>
            <tr>
                
                <input type = submit value = "Submit"></td>
            </tr>
        
        </form>
    </body>
</html> 