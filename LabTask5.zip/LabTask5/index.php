<!DOCTYPE html>
<html>
<head>
<title>Product</title>
</head>
<body>
	<h1 style="color:red">Product Based Website</h1>

	<h3>
		<ul>
	  <li><a href="views/add-product-view.php">Add Product</a></li>
	  <li><a href="views/list-product-view.php">Display Product List</a></li>
	  <li><a href="views/search-product-view.php">Search Product</a></li>
	</ul> 
</h3> 

		
</body>
</html>
